import cv2
from api import api
import imutils
from copy import copy
import time

fileName='output.avi'
capture_duration = 5
cap = cv2.VideoCapture(0)
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi',fourcc, 20.0, (640,480))
start_time = time.time()


while( int(time.time() - start_time) < capture_duration ):
    ret, frame = cap.read()
    if ret==True:
        out.write(frame)
        cv2.imshow("camera",frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
    else:
        break

cap.release()
out.release()
cv2.destroyAllWindows()
l=[]
a=[]
obj=api()
l,a=obj.attention(fileName)
print(l,a)
