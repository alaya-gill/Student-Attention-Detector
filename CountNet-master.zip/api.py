from keras.preprocessing.image import img_to_array
import imutils
import cv2
from keras.models import load_model
import numpy as np
import soundfile as sf
import argparse
import os
import keras
import sklearn
import librosa
from statistics import mode

class api:

    def __init__(self):
        self.detection_model_path = 'haarcascade_files/haarcascade_frontalface_default.xml'
        self.emotion_model_path = 'models/_mini_XCEPTION.102-0.66.hdf5'
        self.eyeCascade= cv2.CascadeClassifier('haarcascade_files/haarcascade_eye.xml')
        self.face_detection = cv2.CascadeClassifier(self.detection_model_path)
        self.emotion_classifier = load_model(self.emotion_model_path, compile=False)
        self.EMOTIONS = ["angry" ,"disgust","scared", "happy", "sad", "surprised",
        "neutral"]
        self.eps = np.finfo(np.float).eps
        # load model
        self.model = keras.models.load_model(
            os.path.join('models', 'RNN_keras2.h5')
        )
        #self.emotion_classifier._make_predict_function()

        
    def __draw_label(self,img, text, pos, bg_color):
        font_face = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.4
        color = (0, 0, 0)
        thickness = cv2.FILLED
        margin = 2

        txt_size = cv2.getTextSize(text, font_face, scale, thickness)

        end_x = pos[0] + txt_size[0][0] + margin
        end_y = pos[1] - txt_size[0][1] - margin

        cv2.rectangle(img, pos, (end_x, end_y), bg_color, thickness)
        cv2.putText(img, text, pos, font_face, scale, color, 1, cv2.LINE_AA)

    def attention(self, fileName):
        attention =[]
        cap = cv2.VideoCapture(fileName)
        pos_frame = cap.get(cv2.CAP_PROP_POS_FRAMES)
        #f = copy(frame)
        labels=[]
        while True:
            success,frame = cap.read()
            frame = imutils.resize(frame,width=1200)
            if success:
                label="no face"
                attentive=False
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = self.face_detection.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,minSize=(30,30),flags=cv2.CASCADE_SCALE_IMAGE)
                
                canvas = np.zeros((250, 300, 3), dtype="uint8")
                frameClone = frame.copy()
                if len(faces) > 0:
                    faces = sorted(faces, reverse=True,
                    key=lambda x: (x[2] - x[0]) * (x[3] - x[1]))[0]
                    (fX, fY, fW, fH) = faces
                                # Extract the ROI of the face from the grayscale image, resize it to a fixed 28x28 pixels, and then prepare
                        # the ROI for classification via the CNN
                    roi = gray[fY:fY + fH, fX:fX + fW]
                    roi_color = frame[fY:fY + fH, fX:fX + fW]
                    eyes = self.eyeCascade.detectMultiScale(roi)
                    if len(eyes)>1:
                        attentive =True
                    roi = cv2.resize(roi, (64, 64))
                    roi = roi.astype("float") / 255.0
                    roi = img_to_array(roi)
                    roi = np.expand_dims(roi, axis=0)

                    preds = self.emotion_classifier.predict(roi)[0]
                    emotion_probability = np.max(preds)
                    label = self.EMOTIONS[preds.argmax()]
                    for (i, (emotion, prob)) in enumerate(zip(self.EMOTIONS, preds)):
                                # construct the label text
                                text = "{}: {:.2f}%".format(emotion, prob * 100)

                                # draw the label + probability bar on the canvas
                            # emoji_face = feelings_faces[np.argmax(preds)]

                                
                                w = int(prob * 300)
                                cv2.rectangle(canvas, (7, (i * 35) + 5),
                                (w, (i * 35) + 35), (0, 0, 255), -1)
                                cv2.putText(canvas, text, (10, (i * 35) + 23),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                                (255, 255, 255), 2)
                                cv2.putText(frameClone, label, (fX, fY - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2)
                                cv2.rectangle(frameClone, (fX, fY), (fX + fW, fY + fH),
                                            (0, 0, 255), 2)
                pos_frame = cap.get(cv2.CAP_PROP_POS_FRAMES)
                attention.append(attentive)
                labels.append(label)
            else:
                cap.set(cv2.CAP_PROP_POS_FRAMES, pos_frame-1)
                cv2.waitKey(1000)
            if cap.get(cv2.CAP_PROP_POS_FRAMES) == cap.get(cv2.CAP_PROP_FRAME_COUNT):
                break
            if success==False:
                break
        #print(mode(a),mode(l))
        return mode(labels),mode(attention)
    def predict_audio_speakers(self,fileName):
        
        
        # load standardisation parameters
        scaler = sklearn.preprocessing.StandardScaler()
        with np.load(os.path.join("models", 'scaler.npz')) as data:
            scaler.mean_ = data['arr_0']
            scaler.scale_ = data['arr_1']

        # compute audio
        audio, rate = sf.read(fileName, always_2d=True)

        # downmix to mono
        audio = np.mean(audio, axis=1)

        # compute STFT
        X = np.abs(librosa.stft(audio, n_fft=400, hop_length=160)).T

        # apply standardization
        X = scaler.transform(X)

        # cut to input shape length (500 frames x 201 STFT bins)
        X = X[:self.model.input_shape[1], :]

        # apply normalization
        Theta = np.linalg.norm(X, axis=1) + self.eps
        X /= np.mean(Theta)

        # add sample dimension
        Xs = X[np.newaxis, ...]

        # predict output
        ys = self.model.predict(Xs, verbose=0)
        return np.argmax(ys, axis=1)[0]