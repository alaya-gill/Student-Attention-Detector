from flask import Flask, request
from api import api
from multiprocessing import Process, Queue, Manager
import json
import multiprocessing
app = Flask(__name__)

@app.route("/video", methods=['POST','GET'])
def hello():
    if request.method=='POST':
        manager = Manager()
        return_dict = manager.dict()
        fileName=request.get_json('video')
        WAVE_OUTPUT_FILENAME=request.get_json('audio')
        l=[]
        a=[]
        print(fileName['video'])
        l=[fileName['video'],WAVE_OUTPUT_FILENAME['audio']]
        print(l)
        manager=multiprocessing.Manager()
        return_dict=manager.dict()

        p = multiprocessing.Process(target=result, args=(l,return_dict))
        p.start()
        p.join()
        count=0
        print(return_dict)
        #count=obj.predict_audio_speakers(WAVE_OUTPUT_FILENAME['audio'])
    return json.dumps(return_dict.copy())

def result(l,return_dict):

    obj=api()
    li,a=obj.attention(l[0])
    count=obj.predict_audio_speakers(l[1])
    return_dict['emotion'] = li
    return_dict['attention'] = a
    return_dict['speakers'] = str(count)
    

if __name__ == "__main__":
    app.run()