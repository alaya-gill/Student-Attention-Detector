import pyaudio
import wave
from api import api
import msvcrt

def transform(data,scale_factor):
    sample = int(data * scale_factor)
    return sample


#Audio parameters
FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 44100
CHUNK = 1024
RECORD_SECONDS = 5
WAVE_OUTPUT_FILENAME = "file.wav"
scale_factor = 2
#get Audio
"""audio = pyaudio.PyAudio()
stream = audio.open(format=FORMAT, channels=CHANNELS,
                rate=RATE, input=True,
                frames_per_buffer=CHUNK)


while True:
    frames = []
    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        #data = transform(data,scale_factor)
        frames.append(data)
    waveFile = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    waveFile.setnchannels(CHANNELS)
    waveFile.setsampwidth(audio.get_sample_size(FORMAT))
    waveFile.setframerate(RATE)
    waveFile.writeframes(b''.join(frames))
    waveFile.close()
    count=obj.predict_audio_speakers(WAVE_OUTPUT_FILENAME)
    print("Count of Speakers",count)
    if msvcrt.kbhit():
        break


stream.stop_stream()
stream.close()
audio.terminate()    """
obj = api()
count=obj.predict_audio_speakers(WAVE_OUTPUT_FILENAME)
print("Count of Speakers",count)